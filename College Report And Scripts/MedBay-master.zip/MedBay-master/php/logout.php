<?php
echo "Hi";
session_destroy();
include './LoginForm.php';
