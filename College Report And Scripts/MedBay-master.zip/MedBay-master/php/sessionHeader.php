<?php
session_start();
$_SESSION["id"] = $id;
$_SESSION["docname"] = $docname;
